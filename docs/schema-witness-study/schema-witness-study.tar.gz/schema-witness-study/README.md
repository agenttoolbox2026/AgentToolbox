# Reproduce the schema witness

Read `REPORT.md` for the result and its limits. This bundle preserves public, pinned source; it does not require provider credentials or network calls when dependencies are already installed.

## Existing Mac environment

```sh
cd /Users/douglascameron/Documents/Codex/2026-10-05/task/schema-witness-study
.venv/bin/python regression.py
```

Expected summary:

```json
{"presence_masks": 8, "original_valid": 3, "converted_valid": 1, "valid_in_both": 0, "mcp_successes": 3, "mcp_errors": 5, "extra_minimal_mcp_successes": 1, "all_assertions_passed": true}
```

## Fresh environment

Use Python 3.12 and Node 24.21.0 (or an environment compatible with these packages). The following commands install dependencies into this directory. Installing dependencies requires network access; the regression itself uses local stdio only.

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
npm install --prefix node-deps --ignore-scripts --save-exact @modelcontextprotocol/sdk@1.32.1
ln -s ../node-deps/node_modules sources/node_modules
STUDY_NODE="$(command -v node)" .venv/bin/python regression.py
```

The `sources/node_modules` command is for a fresh copy without an existing symlink. Do not overwrite an unrelated directory. The working Mac copy reuses the existing SDK dependency read-only instead. `sources/package.json` is an exact copy of the pinned compare-cli root manifest; its package self-reference resolves `compare-cli` to the preserved local source. This test exercises only text, base64 text, and a local fixture file. Optional PDF/DOCX imports are not used or installed.

The script requires `artifacts/original-tool.json`, included in this bundle. It checks the schema received through actual MCP against this artifact and asserts equality between the installed converter and pinned source bytes. To regenerate the original catalog artifact from source:

```sh
node --input-type=module -e 'import {TOOLS} from "./sources/compare-cli-mcp.mjs"; import {writeFileSync} from "node:fs"; writeFileSync("artifacts/original-tool.json", JSON.stringify(TOOLS.find(t => t.name === "compare_files"), null, 2) + "\n")'
```

The converter comes from the installed official `openai-agents==0.23.1` package, not a rewritten implementation. Supporting preserved source and licenses are in `sources/`; `artifacts/source-hashes.json` identifies their bytes.

## Inputs and interpretation

The presence-mask cases apply the same selected modes to both document sides. The minimal text control is separate. `artifacts/results.json` stores all validator errors and MCP responses. `artifacts/witness.json` is the all-three-mode counterexample.

No LLM/provider API client is invoked. Tracing is disabled. No provider schema acceptance, model behavior, product demand, or baseline time improvement is established by passing this regression.
