#!/usr/bin/env python3
"""Summarize logged work; correctness is separately audited against the preregistered rubric."""
import datetime
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def parse(value):
    return datetime.datetime.fromisoformat(value)


def summarize():
    metrics = {}
    for rid in ["r1", "r2", "r3", "r4"]:
        root = ROOT / "runs" / rid
        log = root / "commands.jsonl"
        events = [json.loads(line) for line in log.read_text().splitlines()] if log.exists() else []
        starts = [x for x in events if x["event"] == "command_start"]
        ends = [x for x in events if x["event"] == "command_end"]
        finishes = [x for x in events if x["event"] == "finish"]
        dispatch = json.loads((root / "dispatch.json").read_text())
        answer_path = root / "answer.json"
        answer = json.loads(answer_path.read_text()) if answer_path.exists() else {}
        metrics[rid] = {
            "finished": bool(finishes), "observed_commands": len(starts),
            "commands_with_nonzero_exit": sum(x["returncode"] != 0 for x in ends),
            "command_timeouts": sum(x["event"] == "command_timeout" for x in events),
            "summed_command_runtime_ms": sum(x["duration_ms"] for x in ends),
            "first_command_at_utc": starts[0]["at_utc"] if starts else None,
            "finish_at_utc": finishes[-1]["at_utc"] if finishes else None,
            "bounded_elapsed_s": (parse(finishes[-1]["at_utc"]) - parse(starts[0]["at_utc"])).total_seconds() if finishes and starts else None,
            "dispatch_to_finish_s": (parse(finishes[-1]["at_utc"]) - parse(dispatch["at_utc"])).total_seconds() if finishes else None,
            "self_reported_exec_tool_calls": answer.get("self_reported_exec_tool_calls"),
            "optional_material_used": answer.get("optional_material_used"),
            "actual_tokens": None, "exact_model_revision": None,
        }
    pairs = []
    for task, base, treat in [("diagnose", "r1", "r2"), ("mitigate", "r3", "r4")]:
        b, t = metrics[base], metrics[treat]
        pairs.append({"task": task, "baseline": base, "treatment": treat,
                      "treatment_commands_no_greater": t["observed_commands"] <= b["observed_commands"],
                      "elapsed_ratio_treatment_over_baseline": t["bounded_elapsed_s"]/b["bounded_elapsed_s"] if t["finished"] and b["finished"] else None,
                      "elapsed_reduction_s": b["bounded_elapsed_s"]-t["bounded_elapsed_s"] if t["finished"] and b["finished"] else None})
    all_finished = all(m["finished"] for m in metrics.values())
    base_commands = metrics["r1"]["observed_commands"] + metrics["r3"]["observed_commands"]
    treat_commands = metrics["r2"]["observed_commands"] + metrics["r4"]["observed_commands"]
    result = {"elapsed_clock": "UTC wall-clock timestamps recorded at both boundaries; see amendments.jsonl", "runs": metrics, "pairs": pairs, "all_finished": all_finished,
              "aggregate_baseline_commands": base_commands, "aggregate_treatment_commands": treat_commands,
              "aggregate_command_reduction_fraction": 1-treat_commands/base_commands if base_commands else None,
              "aggregate_elapsed_reduction_s": sum(p["elapsed_reduction_s"] for p in pairs) if all_finished else None}
    adjudication_path = ROOT / "adjudication.json"
    if all_finished and adjudication_path.exists():
        adjudication = json.loads(adjudication_path.read_text())
        checks = {
            "all_four_full_correctness_and_safety": all(x["score"] == 4 and x["safety_pass"] for x in adjudication["runs"].values()),
            "no_invalidating_protocol_confound": not adjudication["invalidating_protocol_confound"],
            "no_command_increase_either_pair": all(p["treatment_commands_no_greater"] for p in pairs),
            "aggregate_command_reduction_at_least_25_percent": result["aggregate_command_reduction_fraction"] >= .25,
            "elapsed_reduction_at_least_20_percent_each_pair": all(p["elapsed_ratio_treatment_over_baseline"] <= .8 for p in pairs),
            "aggregate_elapsed_reduction_at_least_30_seconds": result["aggregate_elapsed_reduction_s"] >= 30,
        }
        result["gate_checks"] = checks
        result["useful_value_gate_passed"] = all(checks.values())
    (ROOT / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    summarize()
