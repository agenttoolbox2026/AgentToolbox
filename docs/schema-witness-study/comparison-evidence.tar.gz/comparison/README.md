# Comparison evidence

Read `REPORT.md` for the result. This bundle preserves a completed four-context comparison; it does not automatically launch agents or rerun their work.

Recompute metrics from unchanged logs and adjudication:

```sh
python3 summarize.py
```

The command needs only Python's standard library. `metrics.json` contains exact values; the report rounds them for readability. Recomputing metrics changes no raw command logs, agent answers or preregistration.

The agents' regression scripts can be rerun in the existing Mac workspace using the installed study `.venv/bin/python` and pinned local sources/dependencies. Follow each run's answer/reproduction instructions. Such checks are post-study verification, not additional comparison observations; do not append them to the frozen run logs or claim they are fresh-agent runs.

The archive does not bundle installed Python/Node dependencies or filesystem symlinks. For a different machine, prepare dependencies using the parent schema-witness-study `requirements.lock` and README, provide Node MCP SDK 1.32.1 under `shared/sources/node_modules`, and adjust machine-specific interpreter paths in run scripts. Preserved source is byte-identical to the pinned source used during the study. Source licenses are included.

`bundle-sha256.json` checks the frozen evidence files. `amendments.jsonl` explains the elapsed-clock extractor correction. No gate thresholds were changed after launch.
