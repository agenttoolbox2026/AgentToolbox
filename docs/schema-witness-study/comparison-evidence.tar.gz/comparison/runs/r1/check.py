"""Offline regression: installed Agents SDK + actual compare-cli MCP stdio server."""
import asyncio, copy, hashlib, importlib.metadata, inspect, json, os
from pathlib import Path
os.environ["OPENAI_AGENTS_DISABLE_TRACING"] = "1"
from agents import Agent, RunContextWrapper, set_tracing_disabled
from agents.mcp import MCPServerStdio
from agents.mcp.util import MCPUtil
from agents.strict_schema import ensure_strict_json_schema
from jsonschema import Draft202012Validator
import agents.strict_schema as strict_module
import agents.mcp.util as util_module
set_tracing_disabled(True)
ROOT = Path(__file__).resolve().parent
SHARED = ROOT.parent.parent / "shared"
ART = ROOT / "artifacts"
NODE = "/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node"
def save(name, data):
    (ART/name).write_text(json.dumps(data, indent=2) + "\n")
def validate(schema, value):
    v = Draft202012Validator(schema)
    return {"valid": v.is_valid(value), "errors": [{"path": list(e.absolute_path), "keyword": e.validator, "message": e.message} for e in v.iter_errors(value)]}
async def main():
    original = json.loads((SHARED/"original-schema.json").read_text())
    supplied = json.loads((SHARED/"converted-schema.json").read_text())
    recreated = ensure_strict_json_schema(copy.deepcopy(original))
    assert recreated == supplied
    side = {"path": str(ART/"fixture.txt"), "content_base64": "SGVsbG8uCg==", "content_text": "Hello.\n", "format": "txt"}
    witness = {"base": side, "candidate": copy.deepcopy(side), "strict": False, "strict_cosmetic": False, "only_clauses": [], "ignore_clauses": [], "include_human_report": False}
    control = {"base": {"content_text": "Payment due within 30 days.\n"}, "candidate": {"content_text": "Payment due within 30 days.\n"}}
    save("witness.json", witness)
    save("control.json", control)
    save("recreated-schema.json", recreated)
    results = {k: {s: validate(schema, value) for s, schema in [("original", original), ("converted", recreated)]} for k,value in [("witness", witness), ("control", control)]}
    assert results["witness"]["converted"]["valid"]
    assert not results["witness"]["original"]["valid"]
    assert results["control"]["original"]["valid"]
    assert not results["control"]["converted"]["valid"]
    save("validation.json", results)
    params = {"command": NODE, "args": [str(SHARED/"sources/compare-cli-mcp.mjs")], "cwd": str(ROOT), "env": {"COMPARE_MCP_BASE_DIR": str(ART), "OPENAI_AGENTS_DISABLE_TRACING": "1"}}
    async with MCPServerStdio(params=params, name="offline-compare", client_session_timeout_seconds=15) as server:
        tools = await server.list_tools()
        tool = next(t for t in tools if t.name == "compare_files")
        assert tool.input_schema == original
        strict_tool = MCPUtil.to_function_tool(tool, server, True)
        normal_tool = MCPUtil.to_function_tool(tool, server, False)
        context = RunContextWrapper(context=None)
        agent = Agent(name="offline-default-config", mcp_servers=[server])
        default_tool = next(t for t in await agent.get_mcp_tools(context) if t.name == "compare_files")
        assert strict_tool.strict_json_schema is True
        assert strict_tool.params_json_schema == recreated
        assert normal_tool.strict_json_schema is False
        assert normal_tool.params_json_schema == original
        assert default_tool.strict_json_schema is False
        assert default_tool.params_json_schema == original
        actual = {}
        for label, value in [("witness", witness), ("control", control)]:
            raw = await server.call_tool("compare_files", value)
            actual[label] = raw.model_dump(mode="json")
        assert actual["witness"]["is_error"] is True
        assert actual["witness"]["structured_content"]["code"] == "INVALID_ARGS"
        assert actual["control"]["is_error"] is False
        assert actual["control"]["structured_content"]["exit_class"] == "clean"
        save("server-results.json", actual)
        # Call the installed adapter invocation path without any provider/model call.
        adapter_witness = await MCPUtil.invoke_mcp_tool(server, tool, context, json.dumps(witness))
        save("adapter-result.json", adapter_witness)
        assert "INVALID_ARGS" in str(adapter_witness)
        assert tool.input_schema == original
        installed = {}
        for module, pinned in [(strict_module,"strict_schema.py"), (util_module,"sdk-mcp-util.py")]:
            source = Path(inspect.getfile(module))
            installed[pinned] = {"installed_path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "matches_supplied_source": source.read_bytes() == (SHARED/"sources"/pinned).read_bytes()}
        agent_source = Path(inspect.getfile(Agent))
        installed["sdk-agent.py"] = {"installed_path":str(agent_source), "matches_supplied_source": agent_source.read_bytes() == (SHARED/"sources/sdk-agent.py").read_bytes()}
        evidence = {"openai_agents":importlib.metadata.version("openai-agents"), "jsonschema":importlib.metadata.version("jsonschema"), "installed_sources":installed, "live_catalog_matches_original":True, "recreated_matches_supplied":True, "strict_conversion":{"strict_json_schema":strict_tool.strict_json_schema,"schema_matches_recreated":True}, "explicit_false_conversion":{"strict_json_schema":normal_tool.strict_json_schema,"schema_unchanged":True}, "default_agent":{"mcp_config":agent.mcp_config,"strict_json_schema":default_tool.strict_json_schema,"schema_unchanged":True}, "original_tool_schema_not_mutated":True}
        save("sdk-evidence.json", evidence)
    print(json.dumps({"validation": {k:{s:v["valid"] for s,v in z.items()} for k,z in results.items()}, "witness_error":actual["witness"], "control_exit_class":actual["control"]["structured_content"]["exit_class"], "sdk_evidence":evidence},indent=2))
if __name__ == "__main__": asyncio.run(main())
