#!/usr/bin/env python3
"""Offline SDK conversion + JSON Schema + actual stdio MCP regression.

No LLM/provider client, credentials, signatures, or payment calls are used.
"""
import asyncio
import copy
import hashlib
import importlib.metadata
import json
import os
import platform
from datetime import datetime, timezone
from pathlib import Path

os.environ["OPENAI_AGENTS_DISABLE_TRACING"] = "1"

from agents import Agent, RunContextWrapper, set_tracing_disabled
import agents.agent
import agents.mcp.util
import inspect
from agents.mcp import MCPServerStdio, MCPUtil
from agents.strict_schema import ensure_strict_json_schema
import agents.strict_schema
from jsonschema import Draft7Validator, Draft202012Validator

set_tracing_disabled(True)
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "artifacts"
SHARED = ROOT.parent.parent / "shared"
NODE = os.environ.get("STUDY_NODE", "/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node")
MODES = ["path", "content_base64", "content_text"]


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def validation(validator, instance):
    errors = sorted(validator.iter_errors(instance), key=lambda e: str(list(e.path)))
    return {"valid": not errors, "errors": [{
        "instance_path": list(e.path), "schema_path": list(e.schema_path),
        "keyword": e.validator, "message": e.message,
    } for e in errors]}


def arguments(mask):
    values = {"path": "artifacts/fixture.txt", "content_base64": "SGVsbG8u", "content_text": "Hello."}
    side = {"format": "txt", **{key: values[key] for i, key in enumerate(MODES) if mask & (1 << i)}}
    return {"base": copy.deepcopy(side), "candidate": copy.deepcopy(side),
            "strict": False, "strict_cosmetic": False, "only_clauses": [],
            "ignore_clauses": [], "include_human_report": False}


async def main():
    assert importlib.metadata.version("openai-agents") == "0.23.1"
    assert importlib.metadata.version("jsonschema") == "4.26.0"
    assert Path(agents.strict_schema.__file__).read_bytes() == (SHARED / "sources/strict_schema.py").read_bytes()
    OUT.mkdir(exist_ok=True)
    (OUT / "fixture.txt").write_text("Hello.")
    results = []
    async with MCPServerStdio(params={"command": NODE, "args": [str(SHARED / "sources/compare-cli-mcp.mjs")], "cwd": str(ROOT)}, name="pinned-compare-cli-offline") as server:
        tools = await server.list_tools()
        tool = next(t for t in tools if t.name == "compare_files")
        original = json.loads((SHARED / "original-tool.json").read_text())["inputSchema"]
        nonstrict = MCPUtil.to_function_tool(tool, server, False)
        strict = MCPUtil.to_function_tool(tool, server, True)
        assert not nonstrict.strict_json_schema
        assert strict.strict_json_schema
        assert nonstrict.params_json_schema == original
        default_agent = Agent(name="offline-default-control", mcp_servers=[server])
        default_tools = await default_agent.get_mcp_tools(RunContextWrapper(context=None))
        default_tool = next(t for t in default_tools if t.name == "compare_files")
        assert default_tool.params_json_schema == original
        assert default_tool.strict_json_schema is False
        assert Path(agents.mcp.util.__file__).read_bytes() == (SHARED / "sources/sdk-mcp-util.py").read_bytes()
        installed_agent_source = Path(inspect.getfile(default_agent.get_mcp_tools)).read_bytes()
        assert installed_agent_source == (SHARED / "sources/sdk-agent.py").read_bytes()
        assert tool.input_schema == original
        converted = strict.params_json_schema
        assert converted == json.loads((SHARED / "converted-schema.json").read_text())
        assert converted == ensure_strict_json_schema(copy.deepcopy(original), _reject_open_objects=True)
        write("original-schema.json", original)
        write("converted-schema.json", converted)
        for cls in (Draft7Validator, Draft202012Validator):
            cls.check_schema(original)
            cls.check_schema(converted)
        for mask in range(8):
            args = arguments(mask)
            call = await server.call_tool("compare_files", args)
            row = {"mask": mask, "modes": [key for i, key in enumerate(MODES) if mask & (1 << i)],
                   "arguments": args,
                   "draft2020_12": {"original": validation(Draft202012Validator(original), args),
                                    "converted": validation(Draft202012Validator(converted), args)},
                   "draft7": {"original_valid": Draft7Validator(original).is_valid(args),
                              "converted_valid": Draft7Validator(converted).is_valid(args)},
                   "mcp_is_error": call.is_error, "mcp_result": call.model_dump(mode="json", by_alias=True)}
            expected_original = mask in (1, 2, 4)
            expected_converted = mask == 7
            assert row["draft2020_12"]["original"]["valid"] == expected_original
            assert row["draft2020_12"]["converted"]["valid"] == expected_converted
            assert row["draft7"]["original_valid"] == expected_original
            assert row["draft7"]["converted_valid"] == expected_converted
            assert bool(call.is_error) == (not expected_original)
            results.append(row)
        minimal = {"base": {"content_text": "Hello."}, "candidate": {"content_text": "Hello."}}
        minimal_call = await server.call_tool("compare_files", minimal)
        minimal_result = {"arguments": minimal, "original_valid": Draft202012Validator(original).is_valid(minimal),
                          "converted_valid": Draft202012Validator(converted).is_valid(minimal),
                          "mcp_is_error": minimal_call.is_error}
        assert minimal_result == {"arguments": minimal, "original_valid": True, "converted_valid": False, "mcp_is_error": False}
    dependencies = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}
    result = {
        "executed_at_utc": datetime.now(timezone.utc).isoformat(), "python": platform.python_version(),
        "dependency_versions": dict(sorted(dependencies.items())), "node": NODE,
        "compare_cli_commit": "8b286320c6f6f8683977a0f2b16293f9fe1b0443",
        "compare_cli_version": "0.4.2", "compare_cli_mcp_version": "0.1.4", "node_mcp_sdk_version": "1.32.1",
        "conversion_path": "MCPUtil.to_function_tool(..., convert_schemas_to_strict=True)",
        "sdk_marked_strict": strict.strict_json_schema,
        "default_conversion_false_preserved_original": nonstrict.params_json_schema == original,
        "provider_api_called": False, "provider_acceptance_verified": False,
        "models_called": 0, "tokens": None, "baseline_comparison": "not assessed in this isolated run",
        "default_agent_schema_preserved": default_tool.params_json_schema == original,
        "installed_sdk_sources_match_supplied": True,
        "cases": results, "minimal_case": minimal_result,
        "summary": {"presence_masks": 8, "original_valid": 3, "converted_valid": 1,
                    "valid_in_both": 0, "mcp_successes": 3, "mcp_errors": 5,
                    "extra_minimal_mcp_successes": 1, "all_assertions_passed": True},
    }
    write("results.json", result)
    write("witness.json", results[-1])
    write("source-hashes.json", {str(p.relative_to(SHARED)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted((SHARED / "sources").iterdir()) if p.is_file()})
    print(json.dumps(result["summary"]))


if __name__ == "__main__":
    asyncio.run(main())
