"""Offline regression: run with the supplied study .venv/bin/python.

Mitigation: Agent(..., mcp_config={"convert_schemas_to_strict": False}).
No Runner/model calls; tool execution uses the actual local MCP stdio server.
"""
import asyncio
import copy
import importlib.metadata
import json
import os
from pathlib import Path

os.environ["OPENAI_AGENTS_DISABLE_TRACING"] = "1"
from agents import Agent, RunContextWrapper, set_tracing_disabled
from agents.mcp import MCPServerStdio
from agents.mcp._compat import result_is_error, result_structured_content
from agents.strict_schema import ensure_strict_json_schema
from agents.tool_context import ToolContext
from jsonschema import Draft202012Validator

set_tracing_disabled(True)
HERE = Path(__file__).resolve().parent
SHARED = HERE.parents[1] / "shared"
NODE = "/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node"

async def main():
    original = json.loads((SHARED / "original-schema.json").read_text())
    converted = ensure_strict_json_schema(copy.deepcopy(original))
    assert converted == json.loads((SHARED / "converted-schema.json").read_text())
    valid = {"base": {"content_text": "A short clause.\n"}, "candidate": {"content_text": "A short clause.\n"}}
    multiple = copy.deepcopy(valid)
    multiple["base"]["path"] = str(HERE / "artifacts/fixture.txt")
    all_modes = {
        "base": {"path": str(HERE / "artifacts/fixture.txt"), "content_base64": "QQ==", "content_text": "A", "format": "txt"},
        "candidate": {"path": str(HERE / "artifacts/fixture.txt"), "content_base64": "QQ==", "content_text": "A", "format": "txt"},
        "strict": False, "strict_cosmetic": False, "only_clauses": [], "ignore_clauses": [], "include_human_report": False,
    }
    assert Draft202012Validator(original).is_valid(valid)
    assert not Draft202012Validator(converted).is_valid(valid)
    assert not Draft202012Validator(original).is_valid(all_modes)
    assert Draft202012Validator(converted).is_valid(all_modes)
    observations = {"sdk_version": importlib.metadata.version("openai-agents"), "direct_conversion_matches_supplied_schema": True, "witnesses": {}, "configurations": {}}
    async with MCPServerStdio(params={"command": NODE, "args": [str(SHARED / "sources/compare-cli-mcp.mjs")], "cwd": str(HERE), "env": {"COMPARE_MCP_BASE_DIR": str(HERE)}}) as server:
        for convert in (True, False):
            agent = Agent(name="offline-schema-regression", mcp_servers=[server], mcp_config={"convert_schemas_to_strict": convert, "failure_error_function": None})
            tools = await agent.get_mcp_tools(RunContextWrapper(context=None))
            tool = next(t for t in tools if t.name == "compare_files")
            schema = tool.params_json_schema
            assert schema == (converted if convert else original), (convert, "unexpected adapter schema")
            assert tool.strict_json_schema is convert
            validator = Draft202012Validator(schema)
            assert validator.is_valid(valid) is (not convert)
            assert not validator.is_valid(multiple)
            assert validator.is_valid(all_modes) is convert
            context = ToolContext(context=None, tool_name=tool.name, tool_call_id="offline-valid", tool_arguments=json.dumps(valid))
            output = await tool.on_invoke_tool(context, json.dumps(valid))
            assert output and "INVALID_ARGS" not in str(output)
            invalid_context = ToolContext(context=None, tool_name=tool.name, tool_call_id="offline-invalid", tool_arguments=json.dumps(multiple))
            try:
                invalid_output = await tool.on_invoke_tool(invalid_context, json.dumps(multiple))
            except Exception as exc:
                rejection = str(exc)
                assert ("exactly one" in rejection or "only one" in rejection) and "INVALID_ARGS" in rejection, rejection
            else:
                rejection = str(invalid_output)
                assert ("exactly one" in rejection or "only one" in rejection) and "INVALID_ARGS" in rejection, rejection
            observations["configurations"][str(convert).lower()] = {"strict_json_schema": tool.strict_json_schema, "schema_equals_original": schema == original, "valid_text_sdk_call_succeeded": True, "multiple_modes_sdk_rejection": rejection}
            (HERE / f"adapter-schema-{str(convert).lower()}.json").write_text(json.dumps(schema, indent=2) + "\n")
        for name, args in [("text_only", valid), ("multiple_modes", multiple), ("all_modes_converted_witness", all_modes)]:
            result = await server.call_tool("compare_files", args)
            is_error = bool(result_is_error(result))
            assert is_error == (name != "text_only"), (name, result)
            if is_error:
                assert "one" in result.content[0].text and "INVALID_ARGS" in result.content[0].text
                assert result_structured_content(result)["code"] == "INVALID_ARGS"
            observations["witnesses"][name] = {"original_valid": Draft202012Validator(original).is_valid(args), "converted_valid": Draft202012Validator(converted).is_valid(args), "server_is_error": is_error, "server_result": result.model_dump(mode="json")}
    (HERE / "results.json").write_text(json.dumps(observations, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "sdk_version": observations["sdk_version"], "configurations": observations["configurations"], "witnesses": {k: {a:b for a,b in v.items() if a != "server_result"} for k,v in observations["witnesses"].items()}}, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
