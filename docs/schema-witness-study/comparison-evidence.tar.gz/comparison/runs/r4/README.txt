Smallest integration mitigation:

    Agent(..., mcp_config={"convert_schemas_to_strict": False})

This restores the original compare_files schema and leaves server validation intact.
The flag is Agent-wide; check its scope if other MCP tools share that Agent.
No provider compatibility is asserted.

Reproduce using the provided installed offline environment:

python3 /Users/douglascameron/Documents/Codex/2026-10-05/task/schema-witness-study/comparison/runner.py r4 exec -- /Users/douglascameron/Documents/Codex/2026-10-05/task/schema-witness-study/.venv/bin/python regression.py

Expected: all_assertions_passed=true, schema_cases=4, stdio_calls=4,
adapted_calls=2, original_schema_preserved=true, provider_called=false.

Evidence is written to artifacts/results.json. Calls use only a local stdio
server, tracing remains disabled, and no model/provider client is invoked.
