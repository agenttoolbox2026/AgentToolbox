"""Offline regression: preserve compare_files input exclusivity through SDK config."""
import asyncio
import copy
import importlib.metadata
import json
import os
from pathlib import Path

os.environ["OPENAI_AGENTS_DISABLE_TRACING"] = "1"
from agents import Agent, RunContextWrapper, set_tracing_disabled
from agents.mcp import MCPServerStdio
from jsonschema import Draft7Validator, Draft202012Validator

set_tracing_disabled(True)
ROOT = Path(__file__).resolve().parent
SHARED = ROOT.parent.parent / "shared"
NODE = "/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node"

async def main():
    assert importlib.metadata.version("openai-agents") == "0.23.1"
    original = json.loads((SHARED / "original-schema.json").read_text())
    ctx = RunContextWrapper(context=None)
    async with MCPServerStdio(params={
        "command": NODE, "args": [str(SHARED / "sources/compare-cli-mcp.mjs")],
        "cwd": str(ROOT),
    }, name="offline-compare") as server:
        # This is the integration mitigation; Agent.get_mcp_tools exercises the
        # installed SDK configuration and conversion path without a model call.
        fixed_agent = Agent(name="compare", mcp_servers=[server],
                            mcp_config={"convert_schemas_to_strict": False})
        fixed = next(t for t in await fixed_agent.get_mcp_tools(ctx)
                     if t.name == "compare_files")
        strict_agent = Agent(name="compare-strict", mcp_servers=[server],
                             mcp_config={"convert_schemas_to_strict": True})
        strict = next(t for t in await strict_agent.get_mcp_tools(ctx)
                      if t.name == "compare_files")
        assert fixed.strict_json_schema is False
        assert fixed.params_json_schema == original
        assert strict.strict_json_schema is True
        assert strict.params_json_schema == json.loads((SHARED / "converted-schema.json").read_text())
        minimal = {"base": {"content_text": "Hello."},
                   "candidate": {"content_text": "Hello."}}
        all_modes = {"path": str(ROOT / "artifacts/fixture.txt"),
                     "content_base64": "SGVsbG8u", "content_text": "Hello.", "format": "txt"}
        witness = {"base": copy.deepcopy(all_modes), "candidate": copy.deepcopy(all_modes),
                   "strict": False, "strict_cosmetic": False,
                   "only_clauses": [], "ignore_clauses": [], "include_human_report": False}
        rows = []
        # Exercise each side independently as well as the all-modes witness.
        cases = [("text_only", minimal, True, False),
                 ("all_modes", witness, False, True)]
        for side in ("base", "candidate"):
            args = copy.deepcopy(minimal)
            args[side]["content_base64"] = "SGVsbG8u"
            cases.append(("two_modes_" + side, args, False, False))
        for name, args, valid_original, valid_strict in cases:
            validation = {}
            for validator in (Draft7Validator, Draft202012Validator):
                validator.check_schema(fixed.params_json_schema)
                validator.check_schema(strict.params_json_schema)
                observed = {"fixed": validator(fixed.params_json_schema).is_valid(args),
                            "strict": validator(strict.params_json_schema).is_valid(args)}
                assert observed == {"fixed": valid_original, "strict": valid_strict}
                validation[validator.__name__] = observed
            # Real stdio server validation, retaining the exact native error.
            result = await server.call_tool("compare_files", args)
            assert bool(result.is_error) is not valid_original
            serialized = result.model_dump(mode="json", by_alias=True)
            if not valid_original:
                assert "INVALID_ARGS" in json.dumps(serialized)
                assert "only one" in json.dumps(serialized)
            rows.append({"name": name, "arguments": args, "validation": validation,
                         "mcp_result": serialized})
        # Also exercise the adapted FunctionTool end to end for the valid case.
        adapted_success = await fixed.on_invoke_tool(ctx, json.dumps(minimal))
        assert "INVALID_ARGS" not in str(adapted_success)
        assert "exit_class" in str(adapted_success)
        # The adapter routes invalid input to unchanged server validation.
        adapted_rejection = await fixed.on_invoke_tool(ctx, json.dumps(witness))
        assert "INVALID_ARGS" in str(adapted_rejection)
        assert "only one" in str(adapted_rejection)
    result = {"sdk_version": importlib.metadata.version("openai-agents"),
              "mitigation": {"mcp_config": {"convert_schemas_to_strict": False}},
              "original_schema_preserved": True, "fixed_marked_strict": False,
              "strict_conversion_reproduced": True, "cases": rows,
              "adapted_success": str(adapted_success),
              "adapted_rejection": str(adapted_rejection),
              "provider_called": False, "all_assertions_passed": True}
    (ROOT / "artifacts/results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"all_assertions_passed": True, "schema_cases": len(rows),
                      "stdio_calls": len(rows), "adapted_calls": 2,
                      "original_schema_preserved": True, "provider_called": False}))

if __name__ == "__main__":
    asyncio.run(main())
