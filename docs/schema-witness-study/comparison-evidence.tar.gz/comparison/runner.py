#!/usr/bin/env python3
"""Record local comparison commands and completion without altering commands."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def append(path, event):
    with path.open("a") as out:
        out.write(json.dumps(event, ensure_ascii=False) + "\n")


parser = argparse.ArgumentParser()
parser.add_argument("run", choices=["r1", "r2", "r3", "r4"])
parser.add_argument("action", choices=["exec", "finish"])
parser.add_argument("rest", nargs=argparse.REMAINDER)
args = parser.parse_args()
run = ROOT / "runs" / args.run
log = run / "commands.jsonl"
if args.action == "finish":
    path = run / "answer.json"
    answer = json.loads(path.read_text())
    assert isinstance(answer, dict)
    event = {"event": "finish", "at_utc": stamp(), "monotonic_ns": time.monotonic_ns(), "answer_path": str(path)}
    append(log, event)
    (run / "finished.json").write_text(json.dumps(event, indent=2) + "\n")
    print("Answer recorded; stop tool work and return your brief final answer.")
    sys.exit(0)
command = args.rest
if command and command[0] == "--":
    command = command[1:]
assert command, "Supply a command after --"
started = time.monotonic_ns()
at = stamp()
append(log, {"event": "command_start", "at_utc": at, "monotonic_ns": started, "command": command})
env = dict(os.environ, OPENAI_AGENTS_DISABLE_TRACING="1", PYTHONDONTWRITEBYTECODE="1")
try:
    result = subprocess.run(command, cwd=run, env=env, capture_output=True, text=True, timeout=75)
    print(result.stdout, end="")
    print(result.stderr, end="", file=sys.stderr)
    ended = time.monotonic_ns()
    append(log, {"event": "command_end", "at_utc": stamp(), "monotonic_ns": ended,
                 "duration_ms": (ended-started)/1e6, "returncode": result.returncode,
                 "stdout": result.stdout, "stderr": result.stderr})
    sys.exit(result.returncode)
except subprocess.TimeoutExpired as exc:
    append(log, {"event": "command_timeout", "at_utc": stamp(), "monotonic_ns": time.monotonic_ns()})
    print("Command exceeded the 75-second per-command bound.", file=sys.stderr)
    sys.exit(124)
